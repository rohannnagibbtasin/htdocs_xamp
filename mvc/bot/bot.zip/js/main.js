let a = document.getElementById("btnadd");

//styling button

a.addEventListener('mousedown',()=>{
    a.style.backgroundColor = "#79caa4b9";
});
a.addEventListener('mouseup',()=>{
    a.style.backgroundColor = "#42cc8cda";
});